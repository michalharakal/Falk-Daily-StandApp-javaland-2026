# Sample TODO App

Simple Java TODO tracker for workshop demos.

## Usage

```
java app.Main
```
