package app;

import java.util.LinkedHashSet;
import java.util.Set;

public class TodoRepository {
  private final Set<String> storage = new LinkedHashSet<>();

  public void save(String todo) {
    storage.add(todo);
  }

  public Set<String> findAll() {
    return Set.copyOf(storage);
  }
}
