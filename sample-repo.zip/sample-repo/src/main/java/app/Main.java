package app;

public class Main {
  public static void main(String[] args) {
    TodoApp app = new TodoApp();
    app.add("Workshop vorbereiten");
    app.add("Slides finalisieren");

    app.list().forEach(System.out::println);
  }
}
