package app;

import java.util.List;

public class TodoApp {
  private final TodoRepository repository = new TodoRepository();

  public void add(String item) {
    repository.save(item);
  }

  public List<String> list() {
    return List.copyOf(repository.findAll());
  }
}
